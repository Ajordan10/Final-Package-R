myconstr <- function(x, y, alpha){
  Rttest
}
