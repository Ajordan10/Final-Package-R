#' @title Plot Title
#'
#' @description The plot title creates boxplots of the data when non - paired data is analyzed.
#'It also will make a boxplot of differences in data when paired = TRUE
#'The Confidence Interval for the difference of means is plotted inside the boxplot of differences.
#'

#' @param x
#' @param ... the remaining arguments
#'
#'
#' @return A plot of the data
#' @importFrom ggplot2 ggplot aes geom_point
#' @export
#'
#'
#' @examples \dontrun {plot.Rttest}

plot.Rttest = function(x, ...){
  y <- NULL #telling created inside the function. initial value
  #data <- data.frame(x=x$x, y=x$y)
  #Cat <- rep(c("A", "B"), c(30,30))
  data <- data.frame(x=x$x, y=x$y)
  #data.frame(MeanValue = c(x,y), TheData = Cat) -> data
  dataf <- ggplot(data)  + geom_boxplot(aes(x= x, y= y))
  dataf <-unlist(dataf)
  plot(x = (x[["data"]]), xlim = range(-50,100), ylim = range(-100,100))
}



