#' Print Function
#'
#'This function prints to the command line  A (1-alpha)100% confidence interval for mux-muy

#' @param ...
#'
#' @param x
#'
#' @return Rttest
#'
#'@export
#'
#' @examples
#' \dontrun {print.Rttest(x,...)}
print.Rttest <- function(x,...) {
  #data = c(Rttest$data,Rttest$Confidence_Interval,Rttest$P.value,Rttest$Alpha)
  #Rttest$data = x[["data"]][["x"]]; x[["data"]][["y"]]
  #dataframe = data.frame(Rttest$data)
  #kable(dataframe)
  kable_styling(kableExtra::kable(x[["data"]],align = "c", col.names = NULL))
  #kable_styling(kableExtra::kable(obj$data,align = "c", col.names = NULL))

}

