#' @title myconstructor
#'
#' @param x xvalue
#' @param y yvalue
#' @param alpha alpha value
#' @param paired paired value
#'
#' @return a list
#' @export

#'
#' @examples
#' \dontrun {myttest(x, y,alpha, paired)}

myttest = function(x, y, alpha, paired){
  if (
    Rttest2 <- t.test(x, y, mu = 0, var.equal = TRUE, conf.level = 1-alpha, paired)) #ttest
    obj <- list(data = data.frame(x=x, y=y), Confidence_Interval = Rttest2$conf.int, P.value = Rttest2$p.value, Alpha = alpha, Paired = paired)
  class(obj) <- 'Rttest'
  obj
  if (Rttest2 <- t.test(x, y, mu = 0, var.equal = FALSE, conf.level = 1-alpha, paired))
    obj <- list(data = data.frame(x=x, y=y), Confidence_Interval = Rttest2$conf.int, P.value = Rttest2$p.value, Alpha = alpha, Paired = paired)
  class(obj) <- 'WELCH'
  obj
  if (Rttest2 <- t.test(x, y, mu = 0, paired = TRUE, conf.level = 1-alpha, paired))
    obj <- list(data = data.frame(x=x, y=y), Confidence_Interval = Rttest2$conf.int, P.value = Rttest2$p.value, Alpha = alpha, Paired = paired)
  class(obj) <- 'PAIRED'
  obj
}

